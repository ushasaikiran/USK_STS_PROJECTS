package com.hcl.gradedrestapi.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.NoArgsConstructor;

@NoArgsConstructor


@Entity
@Table(name="usertable")
public class User {
	
	
	
	@Id
	private int userId;
	
	private String userName;
	
	private String Password;
	
	
}
