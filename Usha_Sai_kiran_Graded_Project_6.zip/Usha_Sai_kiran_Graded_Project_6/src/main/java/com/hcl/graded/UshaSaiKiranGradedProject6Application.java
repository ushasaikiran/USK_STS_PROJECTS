package com.hcl.graded;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UshaSaiKiranGradedProject6Application {

	public static void main(String[] args) {
		SpringApplication.run(UshaSaiKiranGradedProject6Application.class, args);
	}

}
