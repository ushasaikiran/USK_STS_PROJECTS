package com.hcl.graded;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UshaSaiKiranGradedProject6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
