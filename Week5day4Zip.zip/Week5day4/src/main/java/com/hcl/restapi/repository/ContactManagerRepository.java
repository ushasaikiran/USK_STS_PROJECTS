package com.hcl.restapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hcl.restapi.entity.ContactManager;

@Repository
public interface ContactManagerRepository extends JpaRepository<ContactManager, Integer> {

}
