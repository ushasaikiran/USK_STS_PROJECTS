package com.hcl.restapi;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5day4Application {

	public static void main(String[] args) {
		SpringApplication.run(Week5day4Application.class, args);
	}

}
