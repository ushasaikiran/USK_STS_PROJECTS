package com.hcl.restapi.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.hcl.restapi.entity.ContactManager;

@Service
public interface IContactService {

	
	public ContactManager addManager(ContactManager contactmanager);
	
	public ContactManager updateManager(ContactManager contactmanager);
	
	public ContactManager getManagerById(int mid);
	
	public String deleteManagerById(int mid);
	
	public List<ContactManager> getAllManagers();
	
	
	
	
	
}
