package com.hcl.restapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hcl.restapi.entity.ContactManager;
import com.hcl.restapi.repository.ContactManagerRepository;

public class ContactServiceImp implements IContactService {

	
	@Autowired
	ContactManagerRepository repo;
	
	
	@Override
	public ContactManager addManager(ContactManager contactmanager) {
		// TODO Auto-generated method stub
		return repo.save(contactmanager);
	}

	@Override
	public ContactManager updateManager(ContactManager contactmanager) {
		// TODO Auto-generated method stub
		return repo.save(contactmanager);
	}

	@Override
	public ContactManager getManagerById(int mid) {
		// TODO Auto-generated method stub
		return repo.findById(mid).orElse(null); 
	}

	@Override
	public String deleteManagerById(int mid) {
		// TODO Auto-generated method stub
		
		repo.deleteById(mid);
		return "!Manager Deleted!";
	}

	@Override
	public List<ContactManager> getAllManagers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

}
