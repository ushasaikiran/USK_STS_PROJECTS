package com.hcl.mappings.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.mappings.entities.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
