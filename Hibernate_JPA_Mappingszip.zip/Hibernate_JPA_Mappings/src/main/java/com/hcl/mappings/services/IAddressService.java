package com.hcl.mappings.services;

import com.hcl.mappings.entities.Address;

public interface IAddressService {

	
	
	
	public Address addAddress(Address address);
}
