package com.hcl.mappings.services;

import com.hcl.mappings.entities.Student;

public interface IStudentService {

	
	
	public Student addStudent(Student student);
	
}
