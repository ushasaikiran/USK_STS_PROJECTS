package com.hcl.mappings.entities;

import javax.persistence.CascadeType;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;
@NoArgsConstructor
@Data

@Entity
@Table(name="student_table")
public class Student {

	@Id
	private long studentId;
	
	private String studentName;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@Column(name ="aid")
	private Address address;
	
}
