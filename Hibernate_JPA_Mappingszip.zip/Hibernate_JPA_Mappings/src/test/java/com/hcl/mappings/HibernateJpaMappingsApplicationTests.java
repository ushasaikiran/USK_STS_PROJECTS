package com.hcl.mappings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateJpaMappingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
