package com.hcl.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.hcl.beans.User;
import com.hcl.service.IUserService;

@Controller
@RequestMapping("/users")
public class UserController {

	@Autowired
	IUserService serv;
	
	
	@RequestMapping("/entry")
	public String entryPage() {
		
		return "entry";
	}
	

	@RequestMapping(value="/add",method = RequestMethod.POST)
	public String addUser(User user,HttpSession session) {
		
	int cnt = 	serv.addUser(user);

		
		session.setAttribute("status", cnt);
		return "show";
		
	}
	
	
	@RequestMapping(value="/update",method = RequestMethod.POST)
	public String updateUser(User user,HttpSession session) {
		
	int cnt = 	serv.updateUser(user);
		

		
		session.setAttribute("status", cnt);
		return "show";
		
	}
	
	@RequestMapping(value="/delete",method = RequestMethod.POST)
	public String deleteUser(@RequestParam int userId,HttpSession session) {
		
	int cnt = 	serv.deleteUserById(userId);
		

		
		session.setAttribute("status", cnt);
		return "show";
		
	}
	
	@RequestMapping("/getall")
	public String getAll(HttpSession session) {
		
		
		List<User> list = serv.getAllUser();
		
		session.setAttribute("list1", list);
		return "showallusers";
	}
	
}
