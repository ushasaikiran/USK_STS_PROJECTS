package com.hcl.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hcl.beans.Admin;


public interface AdminRepository extends JpaRepository<Admin, Long> {

	
	
	public Admin findByAdminName(String adminName);
}
