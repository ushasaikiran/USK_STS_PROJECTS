package com.hcl.ems.services;

import com.hcl.ems.entities.Address;

public interface IAddressService {

	public Address insertAddress(Address address);
	

	public Address updateAddress(Address address);
	
	
	
	
	
}
