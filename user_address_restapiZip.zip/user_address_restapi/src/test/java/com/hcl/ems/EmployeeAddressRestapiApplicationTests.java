package com.hcl.ems;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeAddressRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
