package com.hcl.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week5day5Application {

	public static void main(String[] args) {
		SpringApplication.run(Week5day5Application.class, args);
	}

}
